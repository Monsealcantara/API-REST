import requests  # Importa la biblioteca requests para realizar solicitudes HTTP

# Realiza una solicitud GET a la URL especificada
# Esta solicitud obtiene datos del servidor y los imprime en formato JSON
response = requests.get('http://127.0.0.1:5000/api')
print(response.json())  # Imprime el contenido de la respuesta en formato JSON

# Realiza una solicitud POST a la URL especificada
# Envía datos en formato JSON al servidor para crear o almacenar información
requestdata = {"name": "John"}  # Datos a enviar en la solicitud POST
response = requests.post('http://127.0.0.1:5000/api', json=requestdata)
print(response.json())  # Imprime la respuesta del servidor en formato JSON

# Realiza una solicitud PUT a la URL especificada
# Envía datos en formato JSON al servidor para actualizar la información existente
updated_data = {"name": "Carlos"}  # Datos actualizados a enviar en la solicitud PUT
response = requests.put('http://127.0.0.1:5000/api', json=updated_data)
print(response.json())  # Imprime la respuesta del servidor en formato JSON

# Realiza una solicitud DELETE a la URL especificada
# Envía una solicitud para eliminar datos en el servidor
response = requests.delete('http://127.0.0.1:5000/api')
print(f"Status Code: {response.status_code}")  # Imprime el código de estado de la respuesta (p. ej., 204 si es exitoso)
print(f"Response Text: {response.text}")  # Imprime el texto de la respuesta

# Intenta convertir la respuesta en formato JSON y manejar el caso de que no sea un JSON
try:
    print(response.json())  # Intenta imprimir la respuesta en formato JSON
except requests.exceptions.JSONDecodeError:
    print("Response is not in JSON format")  # Imprime un mensaje si la respuesta no es JSON
