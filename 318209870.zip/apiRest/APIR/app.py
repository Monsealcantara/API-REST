from flask import Flask, jsonify, request
from marshmallow import Schema, fields, ValidationError
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity

# Crear la instancia principal de la aplicación Flask
app = Flask(__name__)

# Configuración de la clave secreta para la generación y validación de tokens JWT (JSON Web Token)
# Esta clave se utiliza para firmar los tokens y garantizar la autenticidad de los mismos.
app.config['JWT_SECRET_KEY'] = 'super-secret-key'

# Inicializar el administrador de JWT (JWTManager) con la aplicación
jwt = JWTManager(app)

# Configuración de Flask-Limiter para limitar la cantidad de solicitudes permitidas por un usuario
# Limita las solicitudes basadas en la dirección IP del cliente. Esto ayuda a evitar abusos de la API.
limiter = Limiter(
    get_remote_address,  # Utiliza la función para obtener la dirección IP remota del cliente
    app=app,  # Se vincula la limitación a la aplicación Flask
    default_limits=["200 per day", "50 per hour"]  # Establece límites de 200 solicitudes diarias y 50 solicitudes por hora
)

# Definición de un esquema de validación con Marshmallow para validar datos del cliente
# El esquema define qué campos se esperan y sus tipos de datos.
class DataSchema(Schema):
    username = fields.String(required=True)  # Campo de tipo cadena, requerido
    email = fields.Email(required=True)  # Campo de tipo email, requerido
    age = fields.Integer(required=True)  # Campo de tipo entero, requerido

# Crear una instancia del esquema de validación de datos
data_schema = DataSchema()

# Definición de un esquema de validación para las credenciales de inicio de sesión
# Este esquema se utiliza para validar los datos de inicio de sesión del usuario.
class LoginSchema(Schema):
    username = fields.String(required=True)  # Campo de tipo cadena, requerido
    password = fields.String(required=True)  # Campo de tipo cadena, requerido

# Crear una instancia del esquema de validación de inicio de sesión
login_schema = LoginSchema()

# Ruta para autenticación y generación de token JWT
# Permite a los usuarios autenticarse mediante el envío de credenciales válidas.
@app.route('/login', methods=['POST'])
def login():
    try:
        # Validar los datos del cuerpo de la solicitud según el esquema de inicio de sesión
        login_data = login_schema.load(request.get_json())
    except ValidationError as err:
        # Si la validación falla, se devuelven los mensajes de error y un código 400 (Bad Request)
        return jsonify(err.messages), 400

    # Comprobar las credenciales (usuario y contraseña). Esto es solo un ejemplo con valores fijos.
    if login_data['username'] == 'admin' and login_data['password'] == 'password':
        # Crear un token de acceso JWT utilizando el nombre de usuario como identidad
        access_token = create_access_token(identity=login_data['username'])
        return jsonify(access_token=access_token), 200

    # Respuesta en caso de credenciales inválidas
    return jsonify({"msg": "Invalid username or password"}), 401

# Ruta GET protegida por autenticación JWT y con limitación de solicitudes
# Permite acceder a la información solo si se cuenta con un token JWT válido y se cumplen los límites de solicitud.
@app.route('/api', methods=['GET'])
@limiter.limit("10 per minute")  # Límite de 10 solicitudes por minuto para esta ruta
@jwt_required()  # Requiere un token JWT válido para acceder
def get_data():
    # Respuesta de prueba para mostrar que se puede acceder a esta ruta protegida
    return jsonify({"message": "Hello, World!"})

# Ruta POST protegida por autenticación JWT y con validación de datos mediante un esquema
# Permite enviar datos al servidor solo si el usuario está autenticado y los datos cumplen con las reglas del esquema.
@app.route('/api', methods=['POST'])
@jwt_required()  # Requiere un token JWT válido para acceder
def post_data():
    try:
        # Cargar y validar los datos del cuerpo de la solicitud según el esquema definido
        data = data_schema.load(request.get_json())
    except ValidationError as err:
        # Si la validación falla, se devuelven los mensajes de error y un código 400 (Bad Request)
        return jsonify(err.messages), 400

    # Obtener la identidad del usuario autenticado desde el token JWT
    current_user = get_jwt_identity()
    # Responder con los datos validados y la identidad del usuario autenticado
    return jsonify({"user": current_user, "data": data}), 201

# Ruta PUT para actualizar datos, protegida por autenticación JWT
# Permite actualizar datos enviados por el cliente, siempre que el usuario esté autenticado.
@app.route('/api', methods=['PUT'])
@jwt_required()  # Requiere un token JWT válido para acceder
def put_data(): 
    # Obtener los datos enviados en la solicitud PUT
    data = request.get_json() 
    # Simular la actualización de datos y devolver un mensaje de confirmación
    updated_data = {"message": "Data updated", "data": data} 
    return jsonify(updated_data)

# Ruta DELETE para eliminar datos, protegida por autenticación JWT
# Permite eliminar datos del servidor, siempre que el usuario esté autenticado.
@app.route('/api', methods=['DELETE'])
@jwt_required()  # Requiere un token JWT válido para acceder
def delete_data(): 
    # Respuesta de confirmación de eliminación de datos
    return jsonify({"message": "Data deleted"}), 204

# Punto de entrada de la aplicación
# La aplicación se ejecutará solo si este archivo se ejecuta como un script (no si se importa como módulo).
if __name__ == '__main__': 
    # Ejecutar la aplicación en modo de depuración
    app.run(debug=True)
